import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sma/models/task.dart';
import 'package:sma/ui/theme.dart';

class NotifiedPage extends StatelessWidget {
  final String? label;
  final Task? task;
  const NotifiedPage({Key? key, required this.label, this.task})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: _getBGClr(task?.color ?? 0),
          leading: IconButton(
            onPressed: () => Get.back(),
            icon: Icon(Icons.arrow_back_ios),
            color: Colors.black,
          ),
          title: Center(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                this.label.toString().split("|")[0],
                style: headingStyle,
              ),
            ),
          ),
        ),
        body: Center(
          child: Container(
            height: 400,
            width: 300,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: _getBGClr(task?.color ?? 0),
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  this.label.toString().split("|")[1],
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
              ),
            ),
          ),
        ));
  }

  _getBGClr(int no) {
    switch (no) {
      case 0:
        return yellowClr;
      case 1:
        return pinkClr;
      case 2:
        return bluishClr;
      default:
        return yellowClr;
    }
  }
}
